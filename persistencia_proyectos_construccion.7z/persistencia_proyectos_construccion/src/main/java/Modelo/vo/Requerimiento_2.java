package Modelo.vo;

public class Requerimiento_2 {
// Su código    
}
