package Modelo.vo;

public class Requerimiento_1 {
    // Su código
}
