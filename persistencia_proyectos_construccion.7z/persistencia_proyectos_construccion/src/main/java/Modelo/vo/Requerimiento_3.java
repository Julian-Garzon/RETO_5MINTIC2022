package Modelo.vo;

public class Requerimiento_3 {
// Su código
}
